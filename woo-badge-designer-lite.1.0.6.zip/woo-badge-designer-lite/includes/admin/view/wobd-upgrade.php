<?php defined( 'ABSPATH' ) or die( "No script kiddies please!" ); ?>
<div class="wobd-upgrade-wrapper">
    <a href="https://accesspressthemes.com/wordpress-plugins/woo-badge-designer/" target="_blank"><img src="<?php echo WOBD_IMG_DIR . '/upgrade-to-pro.png' ?>" style="width:100%;"></a>
    <div class="wobd-upgrade-button-wrap-backend">
        <a href="http://demo.accesspressthemes.com/wordpress-plugins/woo-badge-designer/" class="smls-demo-btn" target="_blank">Demo</a>
        <a href="https://accesspressthemes.com/wordpress-plugins/woo-badge-designer/" target="_blank" class="smls-upgrade-btn">Upgrade</a>
        <a href="https://accesspressthemes.com/wordpress-plugins/woo-badge-designer/" target="_blank" class="smls-upgrade-btn">Plugin Information</a>
    </div>
    <a href="https://accesspressthemes.com/wordpress-plugins/woo-badge-designer/" target="_blank"> <img src="<?php echo WOBD_IMG_DIR; ?>upgrade-to-pro-feature.png" alt="<?php _e( 'Woo Badge Designer Features', WOBD_TD ); ?>" style="width:100%;"></a>
</div>